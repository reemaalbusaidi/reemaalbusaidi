package studentrentals.service;

import studentrentals.model.*;
import java.util.*;
import java.util.stream.Collectors;

public class ListingService {
    private final AppState state = AppState.getInstance();
    private final Scanner scanner = new Scanner(System.in);

    public void createListing(Homeowner homeowner) {
        System.out.print("Title: ");
        String title = scanner.nextLine().trim();
        System.out.print("Description: ");
        String desc = scanner.nextLine().trim();
        System.out.print("Address: ");
        String addr = scanner.nextLine().trim();
        System.out.print("Price per night: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        System.out.print("Amenities (comma-separated): ");
        String amens = scanner.nextLine().trim();
        List<String> amenities = Arrays.stream(amens.split(","))
                                      .map(String::trim)
                                      .collect(Collectors.toList());

        long id = state.nextListingId();
        Listing listing = new Listing(id, title, desc, addr, price, amenities, homeowner);
        
        homeowner.addListing(listing);
        state.addListing(listing);
        System.out.println("Listing created successfully! ID: " + id);
    }

    public void updateListing(Listing listing) {
        System.out.print("New price per night: ");
        double newPrice = scanner.nextDouble();
        scanner.nextLine();
        listing.setPricePerNight(newPrice);
        System.out.println("Listing updated.");
    }

    public void deactivateListing(Listing listing) {
        listing.setActive(false);
        System.out.println("Listing deactivated.");
    }
}