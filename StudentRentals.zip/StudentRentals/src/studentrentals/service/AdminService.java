package studentrentals.service;

import studentrentals.model.*;
import java.util.Scanner;

public class AdminService {
    private AppState state = AppState.getInstance();
    private Scanner scanner = new Scanner(System.in);

    public void suspendUser() {
        System.out.print("User ID to suspend: "); long id = scanner.nextLong();
        User user = state.getUser(id);
        if (user != null) {
            // Simulate suspend by un-verifying
            user.setVerified(false);
            System.out.println("Suspended.");
        }
    }

    public void suspendListing() {
        System.out.print("Listing ID to suspend: "); long id = scanner.nextLong();
        Listing listing = state.getListing(id);
        if (listing != null) {
            listing.setActive(false);
            System.out.println("Suspended.");
        }
    }
}