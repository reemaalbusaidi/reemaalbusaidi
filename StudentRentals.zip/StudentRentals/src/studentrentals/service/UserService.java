package studentrentals.service;

import studentrentals.model.*;
import java.util.Scanner;

public class UserService {

    private final AppState state = AppState.getInstance();
    private final Scanner scanner = new Scanner(System.in);

    /**
     * Register a new user – prevents duplicate emails
     */
    public User register(String role, String name, String email, String password, String phone) {
        // Make email case-insensitive and trim
        final String normalizedEmail = email.trim().toLowerCase();

        // Check for duplicate email
        boolean emailExists = state.getAllUsers().stream()
                .anyMatch(u -> u.getEmail().equalsIgnoreCase(normalizedEmail));

        if (emailExists) {
            System.out.println("Error: This email is already registered!");
            return null;
        }

        long id = state.nextUserId();
        User user = null;

        switch (role.toLowerCase()) {
            case "student" -> {
                System.out.print("University: ");
                String university = scanner.nextLine().trim();
                user = new Student(id, name, normalizedEmail, password, phone, university);
            }
            case "homeowner" -> user = new Homeowner(id, name, normalizedEmail, password, phone);
            case "admin" -> user = new Admin(id, name, normalizedEmail, password, phone);
            default -> {
                System.out.println("Invalid role! Choose: student, homeowner, or admin");
                return null;
            }
        }

        state.addUser(user);
        System.out.println("Registration successful! Welcome, " + user.getName() + " (ID: " + id + ")");
        return user;
    }

    /**
     * Login – case-insensitive email
     */
    public User login(String email, String password) {
        final String normalizedEmail = email.trim().toLowerCase();

        return state.getAllUsers().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(normalizedEmail) && u.authenticate(password))
                .findFirst()
                .orElse(null);
    }

    /**
     * Helper – check if an email already exists
     */
    public boolean emailExists(String email) {
        final String normalized = email.trim().toLowerCase();
        return state.getAllUsers().stream()
                .anyMatch(u -> u.getEmail().equalsIgnoreCase(normalized));
    }
}