package studentrentals.service;

import studentrentals.model.*;
import java.time.LocalDate;
import java.util.Scanner;


public class BookingService {
    private AppState state = AppState.getInstance();
    private Scanner scanner = new Scanner(System.in);

    public void requestBooking(Student student, Listing listing) {
        System.out.print("Start date (YYYY-MM-DD): "); LocalDate start = LocalDate.parse(scanner.nextLine());
        System.out.print("End date (YYYY-MM-DD): "); LocalDate end = LocalDate.parse(scanner.nextLine());

        if (listing.isAvailable(start, end)) {
            long id = state.nextBookingId();
            Booking booking = new Booking(id, student, listing, start, end);
            state.addBooking(booking);
            listing.addBooking(booking);
            System.out.println("Booking requested: ID " + id);
        } else {
            System.out.println("Not available.");
        }
    }

    public void respondToBooking(Booking booking, boolean accept) {
        if (accept) {
            booking.confirm();
            booking.getListing().blockDates(booking.getStartDate(), booking.getEndDate());
            System.out.println("Confirmed.");
        } else {
            booking.decline();
            System.out.println("Declined.");
        }
    }
}