package studentrentals.service;

import studentrentals.model.*;
import java.time.LocalDate;
import java.util.*;

public class AppState {
    private static AppState instance;
    private Map<Long, User> users = new HashMap<>();
    private Map<Long, Listing> listings = new HashMap<>();
    private Map<Long, Booking> bookings = new HashMap<>();
    private long userIdCounter = 1;
    private long listingIdCounter = 1;
    private long bookingIdCounter = 1;

    private AppState() {} // Private constructor

    public static AppState getInstance() {
        if (instance == null) {
            instance = new AppState();
        }
        return instance;
    }

    // Methods: addUser, getUserById, addListing, etc.
    public void addUser(User user) { users.put(user.getUserId(), user); }
    public User getUser(long id) { return users.get(id); }
    public List<User> getAllUsers() { return new ArrayList<>(users.values()); }

    public void addListing(Listing listing) { listings.put(listing.getListingId(), listing); }
    public Listing getListing(long id) { return listings.get(id); }
    public List<Listing> getAllListings() { return new ArrayList<>(listings.values()); }

    public void addBooking(Booking booking) { bookings.put(booking.getBookingId(), booking); }
    public Booking getBooking(long id) { return bookings.get(id); }

    public long nextUserId() { return userIdCounter++; }
    public long nextListingId() { return listingIdCounter++; }
    public long nextBookingId() { return bookingIdCounter++; }

    // Search (LO4/6): Filter listings
    public List<Listing> searchListings(String location, LocalDate start, LocalDate end, double maxPrice) {
        List<Listing> results = new ArrayList<>();
        for (Listing l : listings.values()) {
            if (l.isActive() && l.getAddress().contains(location) && l.isAvailable(start, end) && l.getPricePerNight() <= maxPrice) {
                results.add(l);
            }
        }
        // Sort by price (simple bubble sort for LO4)
        for (int i = 0; i < results.size() - 1; i++) {
            for (int j = 0; j < results.size() - i - 1; j++) {
                if (results.get(j).getPricePerNight() > results.get(j + 1).getPricePerNight()) {
                    Listing temp = results.get(j);
                    results.set(j, results.get(j + 1));
                    results.set(j + 1, temp);
                }
            }
        }
        return results;
    }
}