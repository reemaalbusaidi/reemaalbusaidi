package studentrentals.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Listing {
    private long listingId;
    private String title;
    private String description;
    private String address;
    private double pricePerNight;
    private List<String> amenities;
    private List<String> photos;
    private boolean isActive;
    private Homeowner owner;                    // ← NEW: who owns this listing
    private List<Availability> availabilities = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();

    // Updated constructor — now requires owner
    public Listing(long listingId, String title, String description, String address,
                   double pricePerNight, List<String> amenities, Homeowner owner) {
        this.listingId = listingId;
        this.title = title;
        this.description = description;
        this.address = address;
        this.pricePerNight = pricePerNight;
        this.amenities = new ArrayList<>(amenities);
        this.photos = new ArrayList<>();
        this.isActive = true;
        this.owner = owner;                     // ← store owner
        this.availabilities = new ArrayList<>();
        this.bookings = new ArrayList<>();
    }

    // Getters
    public long getListingId() { return listingId; }
    public String getTitle() { return title; }
    public String getAddress() { return address; }
    public double getPricePerNight() { return pricePerNight; }
    public boolean isActive() { return isActive; }
    public Homeowner getOwner() { return owner; }           // ← NEW getter

    // Setters
    public void setPricePerNight(double price) { this.pricePerNight = price; }
    public void setActive(boolean active) { this.isActive = active; }

    // Availability methods
    public boolean isAvailable(LocalDate start, LocalDate end) {
        for (Availability av : availabilities) {
            if (av.isBooked() && 
                !(end.isBefore(av.getStartDate()) || start.isAfter(av.getEndDate()))) {
                return false;
            }
        }
        return true;
    }

    public void blockDates(LocalDate start, LocalDate end) {
        availabilities.add(new Availability(start, end, true));
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public List<Booking> getBookings() {
        return new ArrayList<>(bookings);
    }
}