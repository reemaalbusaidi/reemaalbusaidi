package studentrentals.model;

import java.util.ArrayList;
import java.util.List;

public class Homeowner extends User {
    private List<Listing> listings = new ArrayList<>();

    public Homeowner(long userId, String name, String email, String passwordHash, String phone) {
        super(userId, name, email, passwordHash, phone);
    }

    public void addListing(Listing listing) { listings.add(listing); }
    public List<Listing> getListings() { return listings; }
}