package studentrentals.model;

public enum BookingStatus {
    REQUESTED, CONFIRMED, DECLINED, CANCELLED
}