package studentrentals.model;

public class Student extends User {
    private String university;
    // Add preferences if needed

    public Student(long userId, String name, String email, String passwordHash, String phone, String university) {
        super(userId, name, email, passwordHash, phone);
        this.university = university;
    }

    // Getters/Setters
}