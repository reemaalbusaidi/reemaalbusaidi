package studentrentals.model;

import java.time.LocalDate;

public class Availability {
    private LocalDate startDate;
    private LocalDate endDate;
    private boolean isBooked;

    public Availability(LocalDate start, LocalDate end, boolean isBooked) {
        this.startDate = start;
        this.endDate = end;
        this.isBooked = isBooked;
    }

    // Getters
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public boolean isBooked() { return isBooked; }
}