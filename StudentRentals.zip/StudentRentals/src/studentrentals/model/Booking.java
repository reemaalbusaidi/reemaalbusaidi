package studentrentals.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Booking {
    private long bookingId;
    private Student student;
    private Listing listing;
    private LocalDate startDate;
    private LocalDate endDate;
    private BookingStatus status;
    private double totalAmount;
    private LocalDateTime createdAt;

    public Booking(long bookingId, Student student, Listing listing, LocalDate start, LocalDate end) {
        this.bookingId = bookingId;
        this.student = student;
        this.listing = listing;
        this.startDate = start;
        this.endDate = end;
        this.status = BookingStatus.REQUESTED;
        this.totalAmount = listing.getPricePerNight() * (end.toEpochDay() - start.toEpochDay() + 1);
        this.createdAt = LocalDateTime.now();
    }

    // Getters
    public long getBookingId() { return bookingId; }
    public Listing getListing() { return listing; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public BookingStatus getStatus() { return status; }

    // State changes
    public void confirm() { status = BookingStatus.CONFIRMED; }
    public void decline() { status = BookingStatus.DECLINED; }
}