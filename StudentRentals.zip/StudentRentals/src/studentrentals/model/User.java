package studentrentals.model;

import java.time.LocalDateTime;

public abstract class User {
    private long userId;
    private String name;
    private String email;
    private String passwordHash; // Simulate hash with plain text for simplicity
    private String phone;
    private boolean isVerified;
    private LocalDateTime createdAt;

    // Constructor
    public User(long userId, String name, String email, String passwordHash, String phone) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.phone = phone;
        this.isVerified = false;
        this.createdAt = LocalDateTime.now();
    }

    // Getters/Setters (add all)
    public long getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public void setVerified(boolean verified) { this.isVerified = verified; }

    public boolean authenticate(String password) {
        return this.passwordHash.equals(password); // Simple check
    }

    public void verify() { this.isVerified = true; }
}