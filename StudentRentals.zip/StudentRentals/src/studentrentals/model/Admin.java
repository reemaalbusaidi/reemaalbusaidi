package studentrentals.model;

public class Admin extends User {
    public Admin(long userId, String name, String email, String passwordHash, String phone) {
        super(userId, name, email, passwordHash, phone);
    }
}