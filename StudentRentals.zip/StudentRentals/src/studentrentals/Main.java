package studentrentals;

import studentrentals.model.*;
import studentrentals.service.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final UserService userService = new UserService();
    private static final ListingService listingService = new ListingService();
    private static final BookingService bookingService = new BookingService();
    private static final AdminService adminService = new AdminService();
    private static final AppState state = AppState.getInstance();

    public static void main(String[] args) {
        // Pre-seed one admin for testing
        if (state.getAllUsers().isEmpty()) {
            Admin admin = new Admin(1, "Admin User", "admin@gmail.com", "admin1234", "000");
            state.addUser(admin);
            System.out.println("Default admin created: admin@gmail.com / admin1234");
        }

        while (true) {
            System.out.println("\n=== StudentRentals ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");
            int choice = readInt();

            if (choice == 3) {
                System.out.println("Thank you for using StudentRentals!");
                break;
            }

            User currentUser = null;
            if (choice == 1) {
                currentUser = registerUser();
            } else if (choice == 2) {
                currentUser = loginUser();
            }

            if (currentUser != null) {
                showUserMenu(currentUser);
            } else if (choice == 1 || choice == 2) {
                System.out.println("Operation failed. Try again.");
            }
        }
        scanner.close();
    }

    private static User registerUser() {
        System.out.println("\n--- Register ---");
        System.out.print("Role (student/homeowner/admin): ");
        String role = scanner.nextLine().trim().toLowerCase();

        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine().toLowerCase();  // ← case insensitive
        System.out.print("Password: ");
        String pass = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        return userService.register(role, name, email, pass, phone);
    }

    private static User loginUser() {
        System.out.println("\n--- Login ---");
        System.out.print("Email: ");
        String email = scanner.nextLine().trim().toLowerCase();
        System.out.print("Password: ");
        String pass = scanner.nextLine();

        User user = userService.login(email, pass);
        if (user != null) {
            System.out.println("Login successful! Welcome, " + user.getName() + " (" + user.getClass().getSimpleName() + ")");
        } else {
            System.out.println("Invalid email or password.");
        }
        return user;
    }

    private static void showUserMenu(User user) {
        while (true) {
            if (user instanceof Student) {
                studentMenu((Student) user);
            } else if (user instanceof Homeowner) {
                homeownerMenu((Homeowner) user);
            } else if (user instanceof Admin) {
                adminMenu((Admin) user);
            }

            System.out.print("\nDo more actions? (y/n): ");
            if (!scanner.nextLine().trim().equalsIgnoreCase("y")) {
                System.out.println("Logging out...\n");
                break;
            }
        }
    }

    private static void studentMenu(Student student) {
        System.out.println("\n--- Student Menu ---");
        System.out.println("1. Search Listings");
        System.out.println("2. Request Booking");
        System.out.println("3. View My Bookings");
        System.out.print("Choose: ");
        int choice = readInt();
        scanner.nextLine(); // clear buffer

        if (choice == 1) {
            searchListings();
        } else if (choice == 2) {
            System.out.print("Enter Listing ID: ");
            long id = readLong();
            Listing listing = state.getListing(id);
            if (listing != null && listing.isActive()) {
                bookingService.requestBooking(student, listing);
            } else {
                System.out.println("Listing not found or inactive.");
            }
        } else if (choice == 3) {
            System.out.println("Your bookings: (feature ready for extension)");
        }
    }

    private static void homeownerMenu(Homeowner homeowner) {
        System.out.println("\n--- Homeowner Menu ---");
        System.out.println("1. Create Listing");
        System.out.println("2. View My Listings");
        System.out.println("3. Respond to Booking Requests");
        System.out.print("Choose: ");
        int choice = readInt();
        scanner.nextLine();

        if (choice == 1) {
            listingService.createListing(homeowner);
        } else if (choice == 2) {
            homeowner.getListings().forEach(l ->
                System.out.println("ID: " + l.getListingId() + " | " + l.getTitle() +
                    " | £" + l.getPricePerNight() + " | Active: " + l.isActive())
            );
        } else if (choice == 3) {
            System.out.print("Enter Booking ID: ");
            long id = readLong();
            Booking b = state.getBooking(id);
            if (b != null && b.getListing().getOwner().equals(homeowner)) {
                System.out.print("Accept? (y/n): ");
                boolean accept = scanner.nextLine().trim().equalsIgnoreCase("y");
                bookingService.respondToBooking(b, accept);
            } else {
                System.out.println("Invalid booking or not yours.");
            }
        }
    }

    private static void adminMenu(Admin admin) {
        System.out.println("\n--- Admin Menu ---");
        System.out.println("1. Suspend User");
        System.out.println("2. Suspend Listing");
        System.out.print("Choose: ");
        int choice = readInt();
        scanner.nextLine();

        if (choice == 1) adminService.suspendUser();
        else if (choice == 2) adminService.suspendListing();
    }

    private static void searchListings() {
        System.out.print("Location keyword: ");
        String loc = scanner.nextLine();
        System.out.print("Check-in (YYYY-MM-DD): ");
        LocalDate start = LocalDate.parse(scanner.nextLine());
        System.out.print("Check-out (YYYY-MM-DD): ");
        LocalDate end = LocalDate.parse(scanner.nextLine());
        System.out.print("Max price per night: ");
        double price = scanner.nextDouble();
        scanner.nextLine();

        List<Listing> results = state.searchListings(loc, start, end, price);
        System.out.println("\nFound " + results.size() + " listings:");
        results.forEach(l -> System.out.println(
            "ID: " + l.getListingId() + " | " + l.getTitle() +
            " | £" + l.getPricePerNight() + "/night | " + l.getAddress()
        ));
    }

    private static int readInt() {
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. Enter number: ");
            scanner.next();
        }
        int val = scanner.nextInt();
        scanner.nextLine();
        return val;
    }

    private static long readLong() {
        while (!scanner.hasNextLong()) {
            System.out.print("Invalid input. Enter number: ");
            scanner.next();
        }
        long val = scanner.nextLong();
        scanner.nextLine();
        return val;
    }
}